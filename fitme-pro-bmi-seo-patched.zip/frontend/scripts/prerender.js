/**
 * Generate crawlable HTML for every calculator URL after CRA builds the SPA.
 * The React app still hydrates/owns #root in the browser; the static article
 * gives search engines useful content, titles, canonicals and structured data
 * on the initial HTML response.
 */
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const build = path.join(root, "build");
const dataPath = path.join(__dirname, "seo-pages.json");
const indexPath = path.join(build, "index.html");
const siteUrl = (process.env.SITE_URL || "https://fitme-pro.vercel.app").replace(/\/$/, "");

if (!fs.existsSync(indexPath)) {
  throw new Error(`CRA build output not found: ${indexPath}`);
}

const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
const base = fs.readFileSync(indexPath, "utf8");

const esc = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

const json = (value) => JSON.stringify(value).replace(/</g, "\\u003c");

for (const [slug, page] of Object.entries(data)) {
  const canonical = `${siteUrl}/${slug}-calculator`;
  const faq = Array.isArray(page.faq) ? page.faq : [];

  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebApplication",
        name: page.title,
        url: canonical,
        applicationCategory: "HealthApplication",
        operatingSystem: "Web",
        offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
      },
      ...(faq.length
        ? [{
            "@type": "FAQPage",
            mainEntity: faq.map((item) => ({
              "@type": "Question",
              name: item.q,
              acceptedAnswer: { "@type": "Answer", text: item.a },
            })),
          }]
        : []),
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Fitme Pro", item: `${siteUrl}/` },
          { "@type": "ListItem", position: 2, name: page.title, item: canonical },
        ],
      },
    ],
  };

  const steps = (page.steps || [])
    .map((step) => `<li>${esc(step)}</li>`)
    .join("");

  const faqs = faq
    .map((item) => `<details><summary>${esc(item.q)}</summary><p>${esc(item.a)}</p></details>`)
    .join("");

  const seo = `
    <article id="seo-content" style="max-width:900px;margin:0 auto;padding:32px 20px;font-family:Arial,sans-serif">
      <nav aria-label="Breadcrumb"><a href="/">Fitme Pro</a> / <span>${esc(page.title)}</span></nav>
      <h1>${esc(page.title)}</h1>
      <p>${esc(page.intro)}</p>
      <h2>How to use this calculator</h2>
      <ol>${steps}</ol>
      ${(page.sections || []).map((section) => {
        const paragraphs = (section.paragraphs || []).map((p) => `<p>${esc(p)}</p>`).join("");
        const table = section.table ? `<div style="overflow:auto"><table><thead><tr>${section.table[0].map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${section.table.slice(1).map((row) => `<tr>${row.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : "";
        return `<h2>${esc(section.heading)}</h2>${paragraphs}${table}`;
      }).join("")}
      <h2>Formula</h2>
      <p><code>${esc(page.formula)}</code></p>
      ${faqs ? `<h2>Frequently asked questions</h2>${faqs}` : ""}
      <p><a href="/">Explore all 30 Fitme Pro calculators</a></p>
    </article>`;

  let html = base;
  html = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${esc(page.title)} · Fitme Pro</title>`);
  html = html.replace(
    /<meta name="description" content="[^"]*"\s*\/?>(\s*)/i,
    `<meta name="description" content="${esc(page.metaDescription)}" />$1`,
  );
  html = html.replace(/<div id="root"><\/div>/i, `<div id="root">${seo}</div>`);
  html = html.replace(
    /<\/head>/i,
    `<meta name="robots" content="index,follow" />
<link rel="canonical" href="${canonical}" />
<meta property="og:type" content="website" />
<meta property="og:title" content="${esc(page.title)}" />
<meta property="og:description" content="${esc(page.metaDescription)}" />
<meta property="og:url" content="${canonical}" />
<script type="application/ld+json">${json(schema)}</script>
</head>`,
  );

  const dir = path.join(build, "calculator", slug);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "index.html"), html, "utf8");
}

console.log(`Prerendered ${Object.keys(data).length} calculator pages.`);
