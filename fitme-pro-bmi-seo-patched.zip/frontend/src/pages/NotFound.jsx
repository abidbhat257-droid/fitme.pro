import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "@phosphor-icons/react";

export default function NotFound() {
  useEffect(() => {
    document.title = "Page Not Found · Fitme Pro";
  }, []);

  return (
    <div data-testid="not-found-root" className="min-h-[60vh] flex flex-col items-center justify-center text-center px-6 py-20">
      <div className="font-display text-6xl sm:text-7xl uppercase tracking-tighter text-[var(--brand-lime)]">404</div>
      <h1 className="font-display text-2xl sm:text-3xl uppercase tracking-tighter mt-4">Page Not Found</h1>
      <p className="text-muted-foreground mt-3 max-w-md">
        That page doesn't exist. It may have been moved, or the link might be mistyped.
      </p>
      <Link
        to="/"
        className="mt-8 inline-flex items-center gap-2 bg-[var(--brand-lime)] text-black px-5 py-2.5 text-xs font-bold uppercase tracking-[0.15em] hover:bg-white transition-colors"
      >
        <ArrowLeft size={14} /> Back to Dashboard
      </Link>
    </div>
  );
}
