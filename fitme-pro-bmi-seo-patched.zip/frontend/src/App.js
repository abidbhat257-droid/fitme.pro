import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/context/ThemeContext";
import { MeasurementProvider } from "@/context/MeasurementContext";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Dashboard from "@/pages/Dashboard";
import CalculatorPage from "@/pages/CalculatorPage";
import Compare from "@/pages/Compare";
import NotFound from "@/pages/NotFound";
import { CALCULATORS } from "@/lib/calculators";

function App() {
  return (
    <div className="App">
      <ThemeProvider>
        <MeasurementProvider>
          <BrowserRouter>
            <Header />
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/calculator/:slug" element={<CalculatorPage />} />
              {CALCULATORS.map((calculator) => (
                <Route
                  key={calculator.id}
                  path={`/${calculator.slug}-calculator`}
                  element={<CalculatorPage seoSlug={calculator.slug} />}
                />
              ))}
              <Route path="/compare" element={<Compare />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
            <Footer />
            <Toaster position="top-right" richColors closeButton theme="dark" />
          </BrowserRouter>
        </MeasurementProvider>
      </ThemeProvider>
    </div>
  );
}

export default App;
