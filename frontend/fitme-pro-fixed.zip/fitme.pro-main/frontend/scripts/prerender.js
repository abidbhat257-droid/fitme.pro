const fs=require("fs"); const path=require("path");
const root=path.resolve(__dirname,".."); const build=path.join(root,"build");
const data=JSON.parse(fs.readFileSync(path.join(__dirname,"seo-pages.json"),"utf8"));
const base=fs.readFileSync(path.join(build,"index.html"),"utf8");
const esc=s=>String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");
const json=s=>JSON.stringify(s).replace(/</g,"\\u003c");
for(const [slug,p] of Object.entries(data)){
 const canonical=`https://fitme-pro.vercel.app/calculator/${slug}`;
 const faq=p.faq||[];
 const schema={"@context":"https://schema.org","@graph":[{"@type":"WebApplication","name":p.title,"url":canonical,"applicationCategory":"HealthApplication","operatingSystem":"Web","offers":{"@type":"Offer","price":"0","priceCurrency":"USD"}},{"@type":"FAQPage","mainEntity":faq.map(f=>({"@type":"Question",name:f.q,acceptedAnswer:{"@type":"Answer",text:f.a}}))},{"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem",position:1,name:"Fitme Pro",item:"https://fitme-pro.vercel.app/"},{"@type":"ListItem",position:2,name:p.title,item:canonical}]}]};
 const steps=(p.steps||[]).map((x,i)=>`<li>${esc(x)}</li>`).join("");
 const faqs=faq.map(f=>`<details><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join("");
 const seo=`<article id="seo-content" style="max-width:900px;margin:0 auto;padding:32px 20px;font-family:Arial,sans-serif"><nav aria-label="Breadcrumb"><a href="/">Fitme Pro</a> / <span>${esc(p.title)}</span></nav><h1>${esc(p.title)}</h1><p>${esc(p.intro)}</p><h2>How to use this calculator</h2><ol>${steps}</ol><h2>Formula</h2><p><code>${esc(p.formula)}</code></p>${faqs?`<h2>Frequently asked questions</h2>${faqs}`:""}<p><a href="/">Explore all 30 Fitme Pro calculators</a></p></article>`;
 let html=base.replace(/<title>[\s\S]*?<\/title>/i,`<title>${esc(p.title)} · Fitme Pro</title>`);
 html=html.replace(/<meta name="description" content="[^"]*"\s*\/?>(\s*)/i,`<meta name="description" content="${esc(p.metaDescription)}" />$1`);
 html=html.replace(/<div id="root"><\/div>/i,`<div id="root">${seo}</div>`);
 html=html.replace(/<\/head>/i,`<link rel="canonical" href="${canonical}" /><meta property="og:type" content="website" /><meta property="og:title" content="${esc(p.title)}" /><meta property="og:description" content="${esc(p.metaDescription)}" /><meta property="og:url" content="${canonical}" /><script type="application/ld+json">${json(schema)}</script></head>`);
 const dir=path.join(build,"calculator",slug); fs.mkdirSync(dir,{recursive:true}); fs.writeFileSync(path.join(dir,"index.html"),html);
}
console.log(`Prerendered ${Object.keys(data).length} calculator pages.`);