import React from "react";
import { Link } from "react-router-dom";
import { getDedicatedContent } from "@/lib/dedicatedContent";

// Renders the rich, hand-written SEO content for any calculator slug that has
// an entry in lib/dedicatedContent.js. This used to be hardcoded per-calculator
// (see the old BMISEOContent.jsx); it's now generic so every slug added to
// dedicatedContent.js automatically gets the same treatment, live and prerendered.
export default function DedicatedSEOContent({ slug }) {
  const c = getDedicatedContent(slug);
  if (!c) return null;

  return (
    <article className="border-t border-border pt-10 mt-2 space-y-10" aria-label={`${c.classificationTable?.caption || "Calculator"} complete guide`}>
      <section>
        <div className="text-[10px] font-bold uppercase tracking-[0.25em] text-[var(--brand-lime)] mb-2">Complete Guide</div>
        <h2 className="font-display text-3xl sm:text-4xl uppercase tracking-tighter">What Your Result Means</h2>
        <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-8">{c.intro}</p>
      </section>

      <section className="border border-border bg-card p-6 sm:p-7">
        <h3 className="font-display text-xl uppercase tracking-tight mb-3">Quick Answer</h3>
        <p className="text-sm sm:text-base leading-8 text-muted-foreground">{c.quickAnswer}</p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.classificationTable.caption}</h3>
        <div className="overflow-x-auto border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-card">
                {c.classificationTable.columns.map((col) => (
                  <th key={col} className="text-left p-3 font-bold uppercase tracking-wider">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {c.classificationTable.rows.map(([range, category], i) => (
                <tr key={range} className={i < c.classificationTable.rows.length - 1 ? "border-b border-border" : ""}>
                  <td className="p-3">{range}</td>
                  <td className="p-3">{category}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-sm text-muted-foreground leading-8">{c.classificationTable.footnote}</p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">Formula</h3>
        <div className="space-y-3 text-sm sm:text-base text-muted-foreground leading-8">
          <p><strong className="text-foreground">Metric:</strong> {c.formula.metric}</p>
          <p><strong className="text-foreground">Imperial:</strong> {c.formula.imperial}</p>
          <p>{c.formula.note}</p>
        </div>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">How It's Calculated</h3>
        <ol className="space-y-4 text-sm sm:text-base text-muted-foreground leading-8">
          {c.howToSteps.map((step, i) => {
            const [label, ...rest] = step.split(". ");
            return (
              <li key={step}><strong className="text-foreground">{i + 1}. {label}.</strong> {rest.join(". ")}</li>
            );
          })}
        </ol>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.workedExample.heading}</h3>
        <div className="border border-border bg-card p-6">
          <p className="text-sm sm:text-base text-muted-foreground leading-8">{c.workedExample.setup}</p>
          <p className="mt-3 font-mono-data text-sm sm:text-base">{c.workedExample.calculation}</p>
          <p className="mt-3 text-sm text-muted-foreground leading-8">{c.workedExample.result}</p>
        </div>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.comparison.heading}</h3>
        <p className="text-sm sm:text-base text-muted-foreground leading-8">{c.comparison.text}</p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.factors.heading}</h3>
        <ul className="list-disc pl-5 space-y-2 text-sm sm:text-base text-muted-foreground leading-8">
          {c.factors.items.map(([label, text]) => (
            <li key={label}><strong className="text-foreground">{label}:</strong> {text}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.accuracy.heading}</h3>
        <p className="text-sm sm:text-base text-muted-foreground leading-8">{c.accuracy.text}</p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.trackingNote.heading}</h3>
        <p className="text-sm sm:text-base text-muted-foreground leading-8">{c.trackingNote.text}</p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">{c.complementaryMeasures.heading}</h3>
        <p className="text-sm sm:text-base text-muted-foreground leading-8">
          {c.complementaryMeasures.intro}{" "}
          {c.complementaryMeasures.compositionLinks.map((l, i) => (
            <React.Fragment key={l.slug}>
              {i > 0 && (i === c.complementaryMeasures.compositionLinks.length - 1 ? ", and " : ", ")}
              <Link className="text-foreground underline underline-offset-4 hover:text-[var(--brand-lime)]" to={`/${l.slug}`}>{l.name}</Link>
            </React.Fragment>
          ))}
          . {c.complementaryMeasures.midText}{" "}
          {c.complementaryMeasures.planningLinks.map((l, i) => (
            <React.Fragment key={l.slug}>
              {i > 0 && " and "}
              <Link className="text-foreground underline underline-offset-4 hover:text-[var(--brand-lime)]" to={`/${l.slug}`}>{l.name}</Link>
            </React.Fragment>
          ))}{" "}
          {c.complementaryMeasures.outro}
        </p>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">Frequently Asked Questions</h3>
        <div className="space-y-5">
          {c.faqs.map(([q, a]) => (
            <div key={q} className="border-b border-border pb-5">
              <h4 className="font-bold text-sm sm:text-base">{q}</h4>
              <p className="mt-2 text-sm text-muted-foreground leading-7">{a}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h3 className="font-display text-2xl uppercase tracking-tight mb-4">Scientific and Official References</h3>
        <ul className="space-y-3 text-sm text-muted-foreground leading-7">
          {c.references.map((ref) => (
            <li key={ref.url}><a className="underline underline-offset-4 hover:text-foreground" href={ref.url} target="_blank" rel="noreferrer">{ref.label}</a></li>
          ))}
        </ul>
      </section>

      <section className="border border-border p-6 bg-card">
        <h3 className="font-display text-xl uppercase tracking-tight mb-3">Medical Disclaimer</h3>
        <p className="text-sm text-muted-foreground leading-7">{c.disclaimer}</p>
      </section>
    </article>
  );
}
